package m1.projet.emusik;


import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import org.videolan.libvlc.MediaPlayer;

import androidx.annotation.NonNull;
import androidx.appcompat.widget.SearchView;
import androidx.fragment.app.Fragment;

import m1.projet.emusik.Server.Song;
import m1.projet.emusik.client.ClientSession;

public class PlayerFragment extends Fragment implements View.OnClickListener {

    private Button buttonPlayPause;
    public EditText editTextSongURL;

    @Override
    public View onCreateView(
            LayoutInflater inflater, ViewGroup container,
            Bundle savedInstanceState
    ) {
        setHasOptionsMenu(true);
        return inflater.inflate(R.layout.player_fragment, container, false);
    }

    public void onViewCreated(@NonNull View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        buttonPlayPause = (Button) view.findViewById(R.id.playPause);
        buttonPlayPause.setOnClickListener(this);


        Bundle bundle = this.getArguments();
        TextView songTitle = view.findViewById(R.id.songTitle);
        TextView songArtiste = view.findViewById(R.id.songArtiste);

        if(bundle != null && bundle.containsKey("song") && bundle.getSerializable("song") != null){
            Song song = (Song) bundle.getSerializable("song");
            Log.println(Log.INFO, "Song", "Song "+(song.title));
            songTitle.setText(song.title);
            songArtiste.setText(song.artist);
            String audioUrl = ClientSession.getClientSession(view.getContext()).playSong(song);
            onLoad(view, audioUrl);
        }
        else{
            Log.println(Log.INFO, "Null Test", "Bundle "+(bundle==null));
        }

    }
    public void onLoad(View v, String audioUrl){


        MediaPlayer mediaPlayer = ClientSession.getClientSession().getMediaPlayer();
        if(mediaPlayer.isPlaying()){
            mediaPlayer.stop();
        }
        mediaPlayer.play(Uri.parse(audioUrl));
        buttonPlayPause.setBackgroundResource(R.drawable.pause);
    }

    @Override
    public void onClick(View v) {

        MediaPlayer mediaPlayer = ClientSession.getClientSession().getMediaPlayer();
        if(mediaPlayer.isPlaying()){
            mediaPlayer.pause();
            buttonPlayPause.setBackgroundResource(R.drawable.play);
        }
        else {
            mediaPlayer.play();
            buttonPlayPause.setBackgroundResource(R.drawable.pause);
        }
    }

    @Override
    public void onPrepareOptionsMenu(Menu menu) {
        super.onPrepareOptionsMenu(menu);
        menu.findItem(R.id.action_search).setVisible(false);
    }


}
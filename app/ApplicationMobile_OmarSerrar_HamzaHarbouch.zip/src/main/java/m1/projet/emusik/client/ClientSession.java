package m1.projet.emusik.client;

import android.content.Context;
import android.util.Log;

import org.videolan.libvlc.LibVLC;
import org.videolan.libvlc.MediaPlayer;

import m1.projet.emusik.Server.SessionException;
import m1.projet.emusik.Server.Song;
import m1.projet.emusik.Server.StreamServerPrx;

public class ClientSession {
    private static ClientSession CLIENT = null;

    private String session;
    private StreamServerPrx streamServerPrx;
    private LibVLC libVLC;
    private MediaPlayer mediaPlayer;

    ClientSession(Context context){
        connectStreamServer(context);
    }
    private void connectStreamServer(Context context){
        try{
            libVLC = new LibVLC(context);
            mediaPlayer = new MediaPlayer(libVLC);
            com.zeroc.Ice.Communicator communicator = com.zeroc.Ice.Util.initialize(new String[]{"1"});

            com.zeroc.Ice.ObjectPrx base = communicator.stringToProxy("SongPlayer:default -h 192.168.1.58 -p 10000");

            streamServerPrx = StreamServerPrx.checkedCast(base);
            if(streamServerPrx == null)
            {
                throw new Error("Invalid proxy");
            }

            session = streamServerPrx.initClient("0");

            assert session != null;

            Log.println(Log.INFO, "Client", "Session ON: "+session);

        }
        catch (Exception e){
            e.printStackTrace();
        }
    }
    public static ClientSession getClientSession(Context context){
        if(CLIENT != null)
            return CLIENT;
        CLIENT = new ClientSession(context);
        return CLIENT;
    }

    public static ClientSession getClientSession(){
        return CLIENT;
    }


    public String getSession() {
        return session;
    }

    public Song[] getSongs() throws SessionException {
        return streamServerPrx.getSongsList(session);
    }
    public String playSong(Song song){
        try {
            return streamServerPrx.playSong(song, session);
        } catch (SessionException e) {
            e.printStackTrace();
            return "Error";
        }
    }

    public LibVLC getLibVLC() {
        return libVLC;
    }

    public MediaPlayer getMediaPlayer() {
        return mediaPlayer;
    }

    public StreamServerPrx getStreamServerPrx(){
        return streamServerPrx;
    }
}
